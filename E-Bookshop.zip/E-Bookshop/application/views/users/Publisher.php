<!--=== Success msg ===-->
<?php 
    if($this->session->flashdata('reg_success'))
    {
        print '<div class= "success-msg">'.$this->session->flashdata('reg_success').'</div>';
    }
?>

<div class="login-form-area">
    <div class="container">
        <div class="reg-form">
            <div class="form-header">Publisher_Registration Form</div>

           <?= form_open('users/registration')?>

                <div class="form-group">
                    <label for="name"> Full Name</label>
                    <?= form_input(['name'=>'name', 'placeholder'=>'Your full  name...', 'value'=>set_value('name'), 'class'=>'form-control'])?>

 <?= form_open('users/registration')?>

                <div class="form-group">
                    <label for="name"> Tax Registration </label>
                    <?= form_input(['name'=>'name', 'placeholder'=>'Your tax Registration...', 'value'=>set_value('name'), 'class'=>'form-control'])?>

<div class="form-group row">
            <label for="book_file" class="col-sm-2 col-form-label">Book File</label>
            <div class="col-sm-6">
                <?= form_upload(['name'=>'userfile', 'class'=>'form-control'])?>
                <div class="text-secondary">* Upload pdf format. file should not be more than 5MB</div>
            </div>
            <div class="col-sm-4">
               <div class="text-danger form-error"></div>    
            </div>
        </div>

                    <div class="text-danger form-error"><?= form_error('name')?></div>
                </div>
				
				
				
                <div class="form-group">
                    <label for="contact">Contact</label>
                    <?= form_input(['name'=>'contact', 'placeholder'=>'Phone number...', 'value'=>set_value('contact'), 'class'=>'form-control'])?>

                   <div class="text-danger form-error"><?= form_error('contact')?></div>
			 <br>	 
<div class="form-group">				 
				 <label for="contact">Gender</label>
    <input type="radio" name="gender" value="male">Male 
    <input type="radio" name="gender" value="female">Female
	
	 <div class="text-danger form-error"><?= form_error('Gender')?></div>
    <br>
				
				   
                </div>
                <div class="form-group">
                    <label for="email">E-mail</label>
                    <?= form_input(['name'=>'email', 'placeholder'=>'Your email...', 'value'=>set_value('email'), 'class'=>'form-control'])?>

                    <div class="text-danger form-error"><?= form_error('email')?></div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="password">Password</label>
                        <?= form_password(['name'=>'password', 'placeholder'=>'Password...','class'=>'form-control'])?>

                      <div class="text-danger form-error"><?= form_error('password')?></div>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="repassword">Confirm Password</label>
                        <?= form_password(['name'=>'repassword', 'placeholder'=>'Re-type Password...','class'=>'form-control'])?>

                    <div class="text-danger form-error"><?= form_error('repassword')?></div>
                    </div>
                </div>
               <!-- <div class="form-group">
                    <label for="address">Address</label>
                   <!--  <?= form_input(['name'=>'address', 'placeholder'=>'Your address...', 'value'=>set_value('address'), 'class'=>'form-control'])?>-->

                  <!--  <div class="text-danger form-error"><?= form_error('address')?></div>-->
                </div>
                <div class="form-group">
                    <label for="city">City</label>
                      <?= form_input(['name'=>'city', 'placeholder'=>'Your city...', 'value'=>set_value('city'), 'class'=>'form-control'])?>

                    <div class="text-danger form-error"><?= form_error('city')?></div>
                </div>
				
				<div class="form-group">
                    
                          <label for="inputCountry">select Country </label>
                          <select class="custom-select" id="cntry">
						  
		

    <script>

      var country_id = "";
      //var countries = [{"country_id": "5a8d0fccb0445b54856d34e9","country_name": "Guinea"},{"country_id": "5a8d0fccb0445b54856d34ff","country_name": "Belarus"}]
      var obj =  {
        "5a8d0fccb0445b54856d34e9":
        "Guinea"
    ,
        "5a8d0fccb0445b54856d34ff":
        "Belarus"
    ,
        "5a8d0fccb0445b54856d3504":
        "Guadeloupe"
    ,
        "5a8d0fccb0445b54856d3509":
        "Mauritius"
    ,
        "5a8d0fccb0445b54856d3516":
        "Burkina Faso"
    ,
        "5a8d0fccb0445b54856d351a":
        "Laos"
    ,
        "5a8d0fccb0445b54856d353a":
        "Netherlands Antilles"
    ,
        "5a8d0fccb0445b54856d3540":
        "Sint Maarten"
    ,
        "5a8d0fccb0445b54856d3563":
        "Korea North"
    ,
        "5a8d0fccb0445b54856d3575":
        "Uganda"
    ,
        "5a8d0fccb0445b54856d3578":
        "Guyana"
    ,
        "5a8d0fccb0445b54856d358b":
        "Svalbard And Jan Mayen Islands"
    ,
        "5a8d0fccb0445b54856d35a9":
        "Kuwait"
    ,
        "5a8d0fccb0445b54856d35b1":
        "Romania"
    ,
        "5a8d0fccb0445b54856d35b8":
        "Czech Republic"
    ,
        "5a8d0fccb0445b54856d35d3":
        "Philippines"
    ,
        "5a8d0fccb0445b54856d35da":
        "Bermuda"
    ,
        "5a8d0fccb0445b54856d3519":
        "Reunion"
    ,
        "5a8d0fccb0445b54856d351e":
        "Moldova"
    ,
        "5a8d0fccb0445b54856d3530":
        "Indonesia"
    ,
        "5a8d0fccb0445b54856d353d":
        "Panama"
    ,
        "5a8d0fccb0445b54856d354c":
        "Aland Islands"
    ,
        "5a8d0fccb0445b54856d3587":
        "Tajikistan"
    ,
        "5a8d0fccb0445b54856d3590":
        "Cayman Islands"
    ,
        "5a8d0fccb0445b54856d3591":
        "Mayotte"
    ,
        "5a8d0fccb0445b54856d35a7":
        "Croatia"
    ,
        "5a8d0fccb0445b54856d35b0":
        "Kosovo"
    ,
        "5a8d0fccb0445b54856d35c0":
        "Ghana"
    ,
        "5a8d0fccb0445b54856d35cb":
        "Georgia"
    ,
        "5a8d0fccb0445b54856d35cd":
        "Peru"
    ,
        "5a8d0fccb0445b54856d35cf":
        "Barbados"
    ,
        "5a8d0fccb0445b54856d3503":
        "Libya"
    ,
        "5a8d0fccb0445b54856d350b":
        "El Salvador"
    ,
        "5a8d0fccb0445b54856d3517":
        "Kenya"
    ,
        "5a8d0fccb0445b54856d3548":
        "Singapore"
    ,
        "5a8d0fccb0445b54856d3565":
        "Andorra"
    ,
        "5a8d0fccb0445b54856d3572":
        "Guinea-Bissau"
    ,
        "5a8d0fccb0445b54856d3576":
        "Falkland Islands"
    ,
        "5a8d0fccb0445b54856d3583":
        "Guam"
    ,
        "5a8d0fccb0445b54856d35af":
        "Brunei"
    ,
        "5a8d0fccb0445b54856d35be":
        "Haiti"
    ,
        "5a8d0fccb0445b54856d35c2":
        "United Arab Emirates"
    ,
        "5a8d0fccb0445b54856d34f8":
        "Iceland"
    ,
        "5a8d0fccb0445b54856d351b":
        "American Samoa"
    ,
        "5a8d0fccb0445b54856d3525":
        "United States Minor Outlying Islands"
    ,
        "5a8d0fccb0445b54856d352a":
        "Serbia and Montenegro"
    ,
        "5a8d0fccb0445b54856d3533":
        "Palestinian Territory Occupied"
    ,
        "5a8d0fccb0445b54856d353f":
        "Christmas Island"
    ,
        "5a8d0fccb0445b54856d3547":
        "Antigua And Barbuda"
    ,
        "5a8d0fccb0445b54856d3556":
        "Estonia"
    ,
        "5a8d0fccb0445b54856d3558":
        "Bahamas"
    ,
        "5a8d0fccb0445b54856d356f":
        "Belize"
    ,
        "5a8d0fccb0445b54856d3571":
        "Thailand"
    ,
        "5a8d0fccb0445b54856d3584":
        "Jamaica"
    ,
        "5a8d0fccb0445b54856d3588":
        "Greece"
    ,
        "5a8d0fccb0445b54856d358c":
        "Albania"
    ,
        "5a8d0fccb0445b54856d359d":
        "Mongolia"
    ,
        "5a8d0fccb0445b54856d35a1":
        "Morocco"
    ,
        "5a8d0fccb0445b54856d35ac":
        "Macau S.A.R."
    ,
        "5a8d0fccb0445b54856d35ad":
        "Western Sahara"
    ,
        "5a8d0fccb0445b54856d35cc":
        "Bhutan"
    ,
        "5a8d0fccb0445b54856d34df":
        "Bosnia and Herzegovina"
    ,
        "5a8d0fccb0445b54856d34e7":
        "Uzbekistan"
    ,
        "5a8d0fccb0445b54856d3531":
        "Curaçao"
    ,
        "5a8d0fccb0445b54856d3569":
        "San Marino"
    ,
        "5a8d0fccb0445b54856d3573":
        "Kazakhstan"
    ,
        "5a8d0fccb0445b54856d357a":
        "Sweden"
    ,
        "5a8d0fccb0445b54856d3580":
        "Djibouti"
    ,
        "5a8d0fccb0445b54856d358a":
        "Smaller Territories of the UK"
    ,
        "5a8d0fccb0445b54856d3595":
        "Kiribati"
    ,
        "5a8d0fccb0445b54856d3596":
        "Honduras"
    ,
        "5a8d0fccb0445b54856d359a":
        "Swaziland"
    ,
        "5a8d0fccb0445b54856d359b":
        "New Zealand"
    ,
        "5a8d0fccb0445b54856d35a5":
        "Monaco"
    ,
        "5a8d0fccb0445b54856d35b3":
        "Bulgaria"
    ,
        "5a8d0fccb0445b54856d35c5":
        "Saint Vincent And The Grenadines"
    ,
        "5a8d0fccb0445b54856d35d1":
        "Burundi"
    ,
        "5a8d0fccb0445b54856d35d9":
        "Turkmenistan"
    ,
        "5a8d0fccb0445b54856d34fa":
        "Latvia"
    ,
        "5a8d0fccb0445b54856d3522":
        "Slovakia"
    ,
        "5a8d0fccb0445b54856d3561":
        "Pitcairn Island"
    ,
        "5a8d0fccb0445b54856d3570":
        "Portugal"
    ,
        "5a8d0fccb0445b54856d3585":
        "Congo"
    ,
        "5a8d0fccb0445b54856d35a4":
        "Sudan"
    ,
        "5a8d0fccb0445b54856d35b6":
        "Saint Martin"
    ,
        "5a8d0fccb0445b54856d35c4":
        "France"
    ,
        "5a8d0fccb0445b54856d35c7":
        "Syria"
    ,
        "5a8d0fccb0445b54856d35ce":
        "Germany"
    ,
        "5a8d0fccb0445b54856d34db":
        "Fiji Islands"
    ,
        "5a8d0fccb0445b54856d34e0":
        "Malawi"
    ,
        "5a8d0fccb0445b54856d34ec":
        "United States"
    ,
        "5a8d0fccb0445b54856d34ef":
        "Bahrain"
    ,
        "5a8d0fccb0445b54856d3501":
        "Tanzania"
    ,
        "5a8d0fccb0445b54856d3502":
        "Myanmar"
    ,
        "5a8d0fccb0445b54856d3514":
        "Australia"
    ,
        "5a8d0fccb0445b54856d352d":
        "Maldives"
    ,
        "5a8d0fccb0445b54856d3537":
        "Mexico"
    ,
        "5a8d0fccb0445b54856d3539":
        "Marshall Islands"
    ,
        "5a8d0fccb0445b54856d354d":
        "Cyprus"
    ,
        "5a8d0fccb0445b54856d3550":
        "Wallis And Futuna"
    ,
        "5a8d0fccb0445b54856d3560":
        "Grenada"
    ,
        "5a8d0fccb0445b54856d356b":
        "Madagascar"
    ,
        "5a8d0fccb0445b54856d3577":
        "Cuba"
    ,
        "5a8d0fccb0445b54856d357c":
        "Iraq"
    ,
        "5a8d0fccb0445b54856d3589":
        "Saint Kitts And Nevis"
    ,
        "5a8d0fccb0445b54856d358d":
        "Gabon"
    ,
        "5a8d0fccb0445b54856d35b4":
        "East Timor"
    ,
        "5a8d0fccb0445b54856d35b9":
        "External Territories of Australia"
    ,
        "5a8d0fccb0445b54856d35bb":
        "Ethiopia"
    ,
        "5a8d0fccb0445b54856d35d0":
        "Kyrgyzstan"
    ,
        "5a8d0fccb0445b54856d35d7":
        "Cocos (Keeling) Islands"
    ,
        "5a8d0fccb0445b54856d34e3":
        "Tunisia"
    ,
        "5a8d0fccb0445b54856d34f2":
        "Tonga"
    ,
        "5a8d0fccb0445b54856d34f5":
        "Cook Islands"
    ,
        "5a8d0fccb0445b54856d34f9":
        "Malta"
    ,
        "5a8d0fccb0445b54856d3505":
        "French Polynesia"
    ,
        "5a8d0fccb0445b54856d350d":
        "Guatemala"
    ,
        "5a8d0fccb0445b54856d3513":
        "Gambia"
    ,
        "5a8d0fccb0445b54856d3518":
        "Cote d'Ivoire"
    ,
        "5a8d0fccb0445b54856d3520":
        "Egypt"
    ,
        "5a8d0fccb0445b54856d3523":
        "French Guiana"
    ,
        "5a8d0fccb0445b54856d3524":
        "Korea South"
    ,
        "5a8d0fccb0445b54856d352b":
        "Greenland"
    ,
        "5a8d0fccb0445b54856d3553":
        "Vatican City State"
    ,
        "5a8d0fccb0445b54856d355a":
        "Angola"
    ,
        "5a8d0fccb0445b54856d355c":
        "Democratic Republic of the Congo"
    ,
        "5a8d0fccb0445b54856d3564":
        "Bonaire: Saint Eustatius and Saba "
    ,
        "5a8d0fccb0445b54856d3566":
        "Austria"
    ,
        "5a8d0fccb0445b54856d356a":
        "Vanuatu"
    ,
        "5a8d0fccb0445b54856d3579":
        "Chile"
    ,
        "5a8d0fccb0445b54856d3582":
        "New Caledonia"
    ,
        "5a8d0fccb0445b54856d358f":
        "Bangladesh"
    ,
        "5a8d0fccb0445b54856d3593":
        "Anguilla"
    ,
        "5a8d0fccb0445b54856d359c":
        "Guernsey"
    ,
        "5a8d0fccb0445b54856d35c1":
        "Nauru"
    ,
        "5a8d0fccb0445b54856d35c3":
        "Central African Republic"
    ,
        "5a8d0fccb0445b54856d34dc":
        "Gibraltar"
    ,
        "5a8d0fccb0445b54856d34f4":
        "Cameroon"
    ,
        "5a8d0fccb0445b54856d3500":
        "Luxembourg"
    ,
        "5a8d0fccb0445b54856d3512":
        "Ukraine"
    ,
        "5a8d0fccb0445b54856d353e":
        "Slovenia"
    ,
        "5a8d0fccb0445b54856d354e":
        "British Indian Ocean Territory"
    ,
        "5a8d0fccb0445b54856d3557":
        "Taiwan"
    ,
        "5a8d0fccb0445b54856d355f":
        "Isle of Man"
    ,
        "5a8d0fccb0445b54856d3574":
        "Yemen"
    ,
        "5a8d0fccb0445b54856d357b":
        "Sri Lanka"
    ,
        "5a8d0fccb0445b54856d3581":
        "Hong Kong"
    ,
        "5a8d0fccb0445b54856d35a6":
        "Seychelles"
    ,
        "5a8d0fccb0445b54856d35ba":
        "Hungary"
    ,
        "5a8d0fccb0445b54856d35dd":
        "Heard and McDonald Islands"
    ,
        "5a8d0fccb0445b54856d34de":
        "Zambia"
    ,
        "5a8d0fccb0445b54856d34f1":
        "Tokelau"
    ,
        "5a8d0fccb0445b54856d34f6":
        "Jersey"
    ,
        "5a8d0fccb0445b54856d34fd":
        "Botswana"
    ,
        "5a8d0fccb0445b54856d350e":
        "Faroe Islands"
    ,
        "5a8d0fccb0445b54856d350f":
        "Dominica"
    ,
        "5a8d0fccb0445b54856d3510":
        "Paraguay"
    ,
        "5a8d0fccb0445b54856d3515":
        "Montserrat"
    ,
        "5a8d0fccb0445b54856d3521":
        "Italy"
    ,
        "5a8d0fccb0445b54856d352e":
        "Niue"
    ,
        "5a8d0fccb0445b54856d3538":
        "Serbia"
    ,
        "5a8d0fccb0445b54856d3551":
        "Cambodia"
    ,
        "5a8d0fccb0445b54856d3552":
        "Turkey"
    ,
        "5a8d0fccb0445b54856d35a3":
        "India"
    ,
        "5a8d0fccb0445b54856d35b2":
        "Costa Rica"
    ,
        "5a8d0fccb0445b54856d34e5":
        "Rwanda"
    ,
        "5a8d0fccb0445b54856d34f0":
        "Namibia"
    ,
        "5a8d0fccb0445b54856d34f3":
        "Pakistan"
    ,
        "5a8d0fccb0445b54856d34fc":
        "Benin"
    ,
        "5a8d0fccb0445b54856d350a":
        "Azerbaijan"
    ,
        "5a8d0fccb0445b54856d3536":
        "Senegal"
    ,
        "5a8d0fccb0445b54856d3543":
        "Nicaragua"
    ,
        "5a8d0fccb0445b54856d355b":
        "Eritrea"
    ,
        "5a8d0fccb0445b54856d355e":
        "Northern Mariana Islands"
    ,
        "5a8d0fccb0445b54856d3568":
        "Lebanon"
    ,
        "5a8d0fccb0445b54856d3598":
        "Liechtenstein"
    ,
        "5a8d0fccb0445b54856d35a2":
        "Saint Helena"
    ,
        "5a8d0fccb0445b54856d35db":
        "Papua new Guinea"
    ,
        "5a8d0fccb0445b54856d34e1":
        "Argentina"
    ,
        "5a8d0fccb0445b54856d34e4":
        "Venezuela"
    ,
        "5a8d0fccb0445b54856d34e6":
        "Norway"
    ,
        "5a8d0fccb0445b54856d34ea":
        "South Georgia"
    ,
        "5a8d0fccb0445b54856d34ee":
        "Equatorial Guinea"
    ,
        "5a8d0fccb0445b54856d34fb":
        "Somalia"
    ,
        "5a8d0fccb0445b54856d34fe":
        "Niger"
    ,
        "5a8d0fccb0445b54856d3511":
        "Uruguay"
    ,
        "5a8d0fccb0445b54856d351d":
        "Yugoslavia"
    ,
        "5a8d0fccb0445b54856d351f":
        "Saint Pierre and Miquelon"
    ,
        "5a8d0fccb0445b54856d353b":
        "Palau"
    ,
        "5a8d0fccb0445b54856d3541":
        "South Sudan"
    ,
        "5a8d0fccb0445b54856d3546":
        "Colombia"
    ,
        "5a8d0fccb0445b54856d354f":
        "Togo"
    ,
        "5a8d0fccb0445b54856d3567":
        "Jordan"
    ,
        "5a8d0fccb0445b54856d357d":
        "Canada"
    ,
        "5a8d0fccb0445b54856d35a0":
        "Mali"
    ,
        "5a8d0fccb0445b54856d35a8":
        "South Africa"
    ,
        "5a8d0fccb0445b54856d35b5":
        "Nigeria"
    ,
        "5a8d0fccb0445b54856d35bf":
        "Saint Lucia"
    ,
        "5a8d0fccb0445b54856d35d2":
        "Montenegro"
    ,
        "5a8d0fccb0445b54856d35d5":
        "Lithuania"
    ,
        "5a8d0fccb0445b54856d35d6":
        "Iran"
    ,
        "5a8d0fccb0445b54856d350c":
        "Brazil"
    ,
        "5a8d0fccb0445b54856d3526":
        "Turks And Caicos Islands"
    ,
        "5a8d0fccb0445b54856d3527":
        "Mozambique"
      
    ,
        "5a8d0fccb0445b54856d3528":
        "Japan"
    ,
        "5a8d0fccb0445b54856d352f":
        "Afghanistan"
    ,
        "5a8d0fccb0445b54856d354a":
        "Cape Verde"
    ,
        "5a8d0fccb0445b54856d3554":
        "Norfolk Island"
    ,
        "5a8d0fccb0445b54856d355d":
        "Micronesia"
    ,
        "5a8d0fccb0445b54856d357f":
        "Trinidad And Tobago"
    ,
        "5a8d0fccb0445b54856d3586":
        "Puerto Rico"
    ,
        "5a8d0fccb0445b54856d358e":
        "United Kingdom"
    ,
        "5a8d0fccb0445b54856d3597":
        "French Southern Territories"
    ,
        "5a8d0fccb0445b54856d35ab":
        "Switzerland"
    ,
        "5a8d0fccb0445b54856d34f7":
        "Russia"
    ,
        "5a8d0fccb0445b54856d3506":
        "Dominican Republic"
    ,
        "5a8d0fccb0445b54856d351c":
        "Netherlands"
    ,
        "5a8d0fccb0445b54856d3529":
        "Finland"
    ,
        "5a8d0fccb0445b54856d3532":
        "Tuvalu"
    ,
        "5a8d0fccb0445b54856d3549":
        "Zimbabwe"
    ,
        "5a8d0fccb0445b54856d356d":
        "Macedonia"
    ,
        "5a8d0fccb0445b54856d356e":
        "Liberia"
    ,
        "5a8d0fccb0445b54856d3594":
        "Poland"
    ,
        "5a8d0fccb0445b54856d359f":
        "Man (Isle of)"
    ,
        "5a8d0fccb0445b54856d35ae":
        "Samoa"
    ,
        "5a8d0fccb0445b54856d35bc":
        "Lesotho"
    ,
        "5a8d0fccb0445b54856d35ca":
        "Mauritania"
    ,
        "5a8d0fccb0445b54856d35d4":
        "Bouvet Island"
    ,
        "5a8d0fccb0445b54856d34dd":
        "Sao Tome and Principe"
    ,
        "5a8d0fccb0445b54856d34e8":
        "Armenia"
    ,
        "5a8d0fccb0445b54856d3507":
        "Ecuador"
    ,
        "5a8d0fccb0445b54856d3508":
        "Nepal"
    ,
        "5a8d0fccb0445b54856d352c":
        "Vietnam"
    ,
        "5a8d0fccb0445b54856d353c":
        "Antarctica"
    ,
        "5a8d0fccb0445b54856d3542":
        "Saudi Arabia"
    ,
        "5a8d0fccb0445b54856d354b":
        "Martinique"
    ,
        "5a8d0fccb0445b54856d3555":
        "Comoros"
    ,
        "5a8d0fccb0445b54856d3559":
        "China"
    ,
        "5a8d0fccb0445b54856d356c":
        "Oman"
    ,
        "5a8d0fccb0445b54856d3599":
        "Spain"
      
    ,
        "5a8d0fccb0445b54856d359e":
        "Chad"
    ,
        "5a8d0fccb0445b54856d35c8":
        "Saint Barthélemy"
      
    ,
        "5a8d0fccb0445b54856d35c9":
        "Aruba"
    ,
        "5a8d0fccb0445b54856d34e2":
        "Israel"
    ,
      "5a8d0fccb0445b54856d34eb":
      "Belgium" 
    ,
      "5a8d0fccb0445b54856d34ed": 
      "Ireland"
    ,
      "5a8d0fccb0445b54856d3534": 
      "Malaysia"
    ,
      "5a8d0fccb0445b54856d3535": 
      "Solomon Islands"
    ,
      "5a8d0fccb0445b54856d3544": 
      "British Virgin Islands"
    ,
      "5a8d0fccb0445b54856d3545": 
      "Denmark"
    ,
      "5a8d0fccb0445b54856d3562":
      "Guernsey and Alderney"
    ,
      "5a8d0fccb0445b54856d357e": 
      "Suriname"
    ,
      "5a8d0fccb0445b54856d3592": 
      "Virgin Islands (US)"
    ,
      "5a8d0fccb0445b54856d35bd": 
      "Algeria"
    ,
      "5a8d0fccb0445b54856d35c6":
      "Qatar"
    ,
      "5a8d0fccb0445b54856d35d8": 
      "Bolivia"
    ,
       "5a8d0fccb0445b54856d35dc": 
       "Sierra Leone"
    };
      //$.each(countries,function(key, value) 
      $.each(obj,function(key, value) 
      {
        //$("#cntry").append('<option id='+ key["country_id"] +'>' + value["country_name"] + '</option>');
        $("#cntry").append('<option id='+ key +'>' + value + '</option>');
      });

      $("#cntry").on('change',function(){
        //alert($(this).find('option:selected').attr('id'));
        country_id = $(this).find('option:selected').attr('id');
        //alert($(this).find('option:selected').attr('id'));
      });


      registerForm.onsubmit = async (e) => {
        e.preventDefault();

        // get all the inputs into an array.
        var $inputs = $('#registerForm :input');

        // get an associative array of just the values.
        var values = {};
        $.each($('#registerForm').serializeArray(), function(i, field) {
           values[field.name] = field.value;
        });

        var customerType = (values.customerType === 'true');

        var values2 =
          {
            "customer_name": values.customer_name,
            "contact_first_name": values.contact_first_name,
            "customer_legal_name": values.customer_legal_name,
            "customer_code": values.customer_code,
            "individual": customerType,
            "contact_name": values.contact_name,
            "contact_email": values.contact_email,
            "office_address":{
              "address_1": values.address_1,
              "city": values.city,
              "country_id": country_id
            }
          }

          console.log(JSON.stringify(values2));

        //ajax post using basic auth 
        $.ajax({
          url: "https://cors-anywhere.herokuapp.com/https://api.enablex.io/ucaas/v1/customers",
          beforeSend: function(xhr) { 
          xhr.setRequestHeader("Authorization", "Basic " + btoa("5f2e5b0a90ef807c7139b742:5c10ff686ed25d46dca5555c"));
          },
          type: 'POST',
          dataType: 'json',
          contentType: 'application/json',
          processData: false,
          data: JSON.stringify(values2),
          success: function (data) {
            alert(JSON.stringify(data));
          },
          error: function(){
            alert("Cannot get data");
          }
          
        }); 
      };
    </script>
  </body>!-- End #main -->


						  
						  
						  
                          </select>
                        </div>
                  </div>
				  

				
				
                <div class="form-group">
                    <div class="form-check">
                      <?= form_checkbox(['name'=>'conditionBox', 'class'=>'form-check-input', 'value'=> TRUE]);?>
                      <label class="form-check-label" for="term">
                        I declare that all the information given above all are true and valid. By clicking the sign up, you agree to our <a href="<?= base_url()?>users/terms" target ="_blank" class="text-primary">terms and condition</a>. You may receive SMS notifications from us and can opt out at any time.
                      </label>
                    </div>
                    <div class="text-danger form-error"><?= form_error('conditionBox')?></div>
                </div>


                <div class="form-group">
                <?= form_submit(['name'=>'submit','value'=>'Sign Up', 'class'=>'btn btn-primary my-btn']); ?>
                </div>
                <div class="form-group" id="acc">
                    <span>Already have an account?</span>
                    <a href="<?= base_url()?>users/login">Login now</a>
                </div>
            <?= form_close() ?>

            <!--=== Login with social apps ===-->
            <div class="col-lg-12 text-center">
                <span><a href="#" class="btn btn-primary fb"><i class="fab fa-facebook-f"></i> Login with Facebook</a></span>&nbsp
                <span><a href="#" class="btn btn-outline-danger"><i class="fab fa-google"></i> Login with Google &nbsp</a></span>
            </div>

        </div>
    </div>
</div>
