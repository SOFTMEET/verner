<br>
<h5 class = 'success-msg'>You have placed the order successfully. Our sales team will contact you soon.</h5>
<p>Go to user panel to see your order details. </p>
<p>You have to pay the cash at the time of delivery. Thanks for shopping.</p>
<p>Yor cart is empty now. <a href="<?= base_url('users/all_books')?>" class="btn btn-outline-success btn-sm">Continue Shopping</a></p>