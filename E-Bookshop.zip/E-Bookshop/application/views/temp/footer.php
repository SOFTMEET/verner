<div class="footer-area">
    <div class="container">
        <div id="s-footer">
            <div class="col-md-12 col-sm-12">
                <div class="footer-text">
                    <p><i class="fas fa-copyright"></i> Softtechz, Inc. <br>
                        Email: @gmail.com</p>
                </div>
                <div id="social-icon">
                    <span><a href="https://www.facebook.com/" title="Facebook" target="_blank"><i class="fab fa-facebook-f"></i></a></span>
                    <span><a href="https://github.com/" title="Github" target="_blank"><i class="fab fa-github"></i></a></span>
                    <span><a href="https://www.instagram.com/" title="Instagram" target="_blank"><i class="fab fa-instagram"></i></a></span>
					
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script type="text/javascript" src="<?= base_url('tool/js/popper-1.12.9.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('tool/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('tool/js/all.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('tool/js/owl.carousel.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('tool/js/main.js'); ?>"></script>
</body>

</html>
